# YKD App - Docker Development Guide

Complete guide for developing the YKD workout app using Docker containers.

## 📋 Table of Contents

1. [Prerequisites](#prerequisites)
2. [Quick Start](#quick-start)
3. [Project Structure](#project-structure)
4. [Available Commands](#available-commands)
5. [Development Workflow](#development-workflow)
6. [Configuration](#configuration)
7. [Troubleshooting](#troubleshooting)

---

## 🔧 Prerequisites

Before you begin, ensure you have installed:

- **Docker**: Version 20.10 or higher
- **Docker Compose**: Version 2.0 or higher
- **Make** (optional, for easier commands)

### Installation

**macOS (with Homebrew):**
```bash
brew install docker docker-compose
```

**Ubuntu/Debian:**
```bash
sudo apt-get update
sudo apt-get install docker.io docker-compose
```

**Windows:**
Download and install [Docker Desktop](https://www.docker.com/products/docker-desktop)

---

## 🚀 Quick Start

### Option 1: Using Make (Recommended)

```bash
# Build the Docker image
make build

# Start the development server (SvelteKit)
make up

# Or start Vite version
make up-vite
```

### Option 2: Using Docker Compose

```bash
# Build the Docker image
docker-compose build

# Start SvelteKit development server
docker-compose up sveltekit

# Or start Vite development server
docker-compose --profile vite up vite
```

### Access the Application

**SvelteKit:** http://localhost:5173
**Vite:** http://localhost:5174

---

## 📁 Project Structure

```
ykd-app/
├── Dockerfile.dev           # Development Dockerfile
├── docker-compose.yml       # Docker Compose configuration
├── .dockerignore           # Files to exclude from Docker
├── Makefile                # Convenience commands
├── svelte.config.js        # SvelteKit config (Docker-ready)
├── vite.config.ts          # Vite config (Docker-ready)
├── src/                    # Application source code
├── static/                 # Static assets (SvelteKit)
├── public/                 # Public assets (Vite)
└── node_modules/           # Dependencies (created in container)
```

---

## 🎯 Available Commands

### Using Make

| Command | Description |
|---------|-------------|
| `make help` | Show all available commands |
| `make build` | Build Docker images |
| `make up` | Start SvelteKit dev server |
| `make up-vite` | Start Vite dev server |
| `make up-d` | Start in background (detached) |
| `make down` | Stop all containers |
| `make logs` | View container logs |
| `make logs-follow` | Follow container logs in real-time |
| `make restart` | Restart containers |
| `make clean` | Remove containers and volumes |
| `make shell` | Open shell in running container |
| `make install` | Install/update npm dependencies |
| `make npm <command>` | Run any npm command in container |

### Using Docker Compose

```bash
# Build
docker-compose build

# Start (SvelteKit)
docker-compose up sveltekit

# Start (Vite)
docker-compose --profile vite up vite

# Start in background
docker-compose up -d sveltekit

# Stop
docker-compose down

# View logs
docker-compose logs -f sveltekit

# Run npm commands
docker-compose run --rm sveltekit npm install
docker-compose run --rm sveltekit npm run build

# Open shell
docker-compose exec sveltekit sh
```

---

## 💻 Development Workflow

### 1. Initial Setup

```bash
# Clone the repository
git clone <your-repo-url>
cd ykd-app

# Build Docker image
make build

# Start development server
make up
```

### 2. Making Changes

All file changes are automatically detected via hot module replacement (HMR):

1. Edit files in `src/`
2. Save your changes
3. Browser automatically refreshes

**Note:** File watching uses polling in Docker, so updates may take 1-2 seconds.

### 3. Installing New Packages

```bash
# Using Make
make npm install <package-name>

# Or directly with docker-compose
docker-compose run --rm sveltekit npm install <package-name>

# Example: Install a new dependency
make npm install chart.js
```

### 4. Running Commands

```bash
# Check TypeScript
make npm run check

# Build for production
make npm run build

# Run tests
make npm test
```

### 5. Debugging

```bash
# View real-time logs
make logs-follow

# Open shell in container
make shell

# Inside the container, you can:
# - Run commands directly
# - Inspect files
# - Check environment variables
```

---

## ⚙️ Configuration

### Docker Compose Options

#### SvelteKit Service

```yaml
services:
  sveltekit:
    ports:
      - "5173:5173"      # Change external port if needed
    volumes:
      - ./src:/app/src   # Mount source for hot reload
      - /app/node_modules # Prevent overwriting
    environment:
      - NODE_ENV=development
```

#### Vite Service

The Vite service is configured with a profile to avoid port conflicts:

```bash
# Start only Vite
docker-compose --profile vite up vite

# It runs on port 5174
```

### Vite Configuration (vite.config.ts)

```typescript
export default defineConfig({
  server: {
    host: '0.0.0.0',     // Required for Docker
    port: 5173,
    strictPort: true,
    watch: {
      usePolling: true,  // Enable polling in Docker
      interval: 1000     // Check every 1 second
    }
  }
})
```

### SvelteKit Configuration (svelte.config.js)

```javascript
const config = {
  kit: {
    vite: {
      server: {
        host: '0.0.0.0',
        watch: {
          usePolling: true
        }
      }
    }
  }
};
```

---

## 🐛 Troubleshooting

### Hot Reload Not Working

**Problem:** Changes to files don't trigger browser refresh.

**Solution:**
```bash
# Ensure polling is enabled in vite.config.ts
watch: {
  usePolling: true,
  interval: 1000
}

# Restart the container
make restart
```

### Port Already in Use

**Problem:** `Error: Port 5173 is already in use`

**Solution:**
```bash
# Stop any running containers
make down

# Or kill the process using the port
lsof -ti:5173 | xargs kill -9

# Use a different port in docker-compose.yml
ports:
  - "3000:5173"  # Access on localhost:3000
```

### Slow File Changes

**Problem:** Changes take a long time to reflect.

**Solution:**
```bash
# Reduce polling interval in vite.config.ts
watch: {
  usePolling: true,
  interval: 500  # Check every 500ms
}
```

### Permission Issues

**Problem:** `EACCES: permission denied` errors.

**Solution:**
```bash
# On Linux, fix ownership
sudo chown -R $USER:$USER .

# Or run with correct user in Dockerfile
USER node
```

### Container Won't Start

**Problem:** Container exits immediately.

**Solution:**
```bash
# Check logs for errors
make logs

# Common issues:
# 1. Missing package.json
# 2. Syntax errors in config files
# 3. Port conflicts

# Rebuild from scratch
make clean
make build
make up
```

### node_modules Not Found

**Problem:** Dependencies not available in container.

**Solution:**
```bash
# Install dependencies in container
make install

# Or rebuild with fresh install
make clean
make build
```

### Memory Issues

**Problem:** Container runs out of memory.

**Solution:**

Add memory limits in docker-compose.yml:
```yaml
services:
  sveltekit:
    mem_limit: 2g
    memswap_limit: 2g
```

---

## 🔒 Security Notes

### Development Only

This Docker setup is **for development only**. Do not use in production.

For production:
1. Use a multi-stage Dockerfile
2. Run as non-root user
3. Use production adapters
4. Minimize image size
5. Scan for vulnerabilities

### Environment Variables

Never commit sensitive data:
```bash
# Use .env files (add to .gitignore)
echo ".env*" >> .gitignore

# Example .env
DATABASE_URL=postgresql://localhost:5432/mydb
API_KEY=your-secret-key
```

---

## 📝 Advanced Usage

### Multiple Containers

Run both SvelteKit and Vite simultaneously:

```bash
# Terminal 1: SvelteKit on :5173
docker-compose up sveltekit

# Terminal 2: Vite on :5174
docker-compose --profile vite up vite
```

### Custom Docker Compose Files

```bash
# Development
docker-compose -f docker-compose.yml up

# Production (if you create it)
docker-compose -f docker-compose.prod.yml up
```

### Volume Management

```bash
# List volumes
docker volume ls

# Inspect volume
docker volume inspect ykd-app_node_modules

# Remove unused volumes
docker volume prune
```

### Network Inspection

```bash
# List networks
docker network ls

# Inspect network
docker network inspect ykd-app_ykd-network

# Connect container to network
docker network connect ykd-network <container-name>
```

---

## 🚢 Next Steps

1. **Production Build**: Create a production Dockerfile
2. **CI/CD**: Set up GitHub Actions or GitLab CI
3. **Testing**: Add testing containers
4. **Database**: Add PostgreSQL/MySQL containers if needed
5. **Nginx**: Add reverse proxy for production

---

## 📚 Resources

- [Docker Documentation](https://docs.docker.com/)
- [Docker Compose Reference](https://docs.docker.com/compose/)
- [SvelteKit Docker Guide](https://kit.svelte.dev/docs/adapter-node)
- [Vite Docker Setup](https://vitejs.dev/guide/)

---

## 🆘 Getting Help

If you encounter issues:

1. Check the [Troubleshooting](#troubleshooting) section
2. View container logs: `make logs-follow`
3. Open a shell: `make shell`
4. Check Docker status: `docker ps -a`

---

## 📄 License

GPL v3.0 - Same as the YKD project
